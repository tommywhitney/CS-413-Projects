#	Project	1
##	Pair Poker
*	Peter Galvan (pjg94)
*	Camden Hortline (cjh547)
*	Thomas Whitney (tdw226)

##	Instructions
You will be booting into a title screen. Click once to advance to the game board. Click on a card to reveal its face, and try
to find both of the aces. When two cards have been flipped that are not aces, they will be flipped back over. Find the aces in
the minimum amount of guesses.

##	Known	Bugs	or	Issues
Describe	any	known	issues	with	your	game.

No known Bugs or Issues

##	Credits
*	Peter Galvan: Created sprites, rooms, and helped with source code logic.	
*	Camden Hortline: Helped work out logic in code and create and implement tweens, Helped add details to Title and End Screen sprites.
*	Thomas Whitney: Helped develop logic for the game and create and implement sequences.
